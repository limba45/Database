﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace WindowsFormsApp1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.ShowDialog();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Admissions f = new Admissions();
            f.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Blocks f = new Blocks();
            f.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Building f = new Building();
            f.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Employees f = new Employees();
            f.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Room f = new Room();
            f.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            GeneralWards f = new GeneralWards();
            f.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Patient f = new Patient();
            f.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Bill f = new Bill();
            f.ShowDialog();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            Report f = new Report();
            f.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Doctor f = new Doctor();
            f.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Nurse f = new Nurse();
            f.ShowDialog();
        }
    }
}