﻿
namespace WindowsFormsApp1
{
    partial class Nurse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.insertName = new System.Windows.Forms.TextBox();
            this.insertRole = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.insertDoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.updateRole = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.updateName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.updateID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.deleteID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV
            // 
            this.DGV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DGV.Location = new System.Drawing.Point(12, 175);
            this.DGV.Name = "DGV";
            this.DGV.Size = new System.Drawing.Size(1187, 461);
            this.DGV.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Name";
            // 
            // insertName
            // 
            this.insertName.Location = new System.Drawing.Point(139, 27);
            this.insertName.Name = "insertName";
            this.insertName.Size = new System.Drawing.Size(100, 20);
            this.insertName.TabIndex = 11;
            // 
            // insertRole
            // 
            this.insertRole.Location = new System.Drawing.Point(139, 53);
            this.insertRole.Name = "insertRole";
            this.insertRole.Size = new System.Drawing.Size(100, 20);
            this.insertRole.TabIndex = 13;
            this.insertRole.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Role";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // insertDoc
            // 
            this.insertDoc.Location = new System.Drawing.Point(139, 79);
            this.insertDoc.Name = "insertDoc";
            this.insertDoc.Size = new System.Drawing.Size(100, 20);
            this.insertDoc.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Doctor";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(79, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "INSERT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // updateRole
            // 
            this.updateRole.Location = new System.Drawing.Point(495, 53);
            this.updateRole.Name = "updateRole";
            this.updateRole.Size = new System.Drawing.Size(100, 20);
            this.updateRole.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(432, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Role";
            // 
            // updateName
            // 
            this.updateName.Location = new System.Drawing.Point(495, 27);
            this.updateName.Name = "updateName";
            this.updateName.Size = new System.Drawing.Size(100, 20);
            this.updateName.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(432, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Name";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(435, 118);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // updateID
            // 
            this.updateID.Location = new System.Drawing.Point(495, 82);
            this.updateID.Name = "updateID";
            this.updateID.Size = new System.Drawing.Size(100, 20);
            this.updateID.TabIndex = 23;
            this.updateID.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(432, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "ID";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // deleteID
            // 
            this.deleteID.Location = new System.Drawing.Point(818, 27);
            this.deleteID.Name = "deleteID";
            this.deleteID.Size = new System.Drawing.Size(100, 20);
            this.deleteID.TabIndex = 24;
            this.deleteID.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(755, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "ID";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(758, 118);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 23);
            this.button3.TabIndex = 26;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Nurse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 648);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.deleteID);
            this.Controls.Add(this.updateID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.updateRole);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.updateName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.insertDoc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.insertRole);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.insertName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV);
            this.Name = "Nurse";
            this.Text = "Nurse";
            this.Load += new System.EventHandler(this.Nurse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox insertName;
        private System.Windows.Forms.TextBox insertRole;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox insertDoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox updateRole;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox updateName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox updateID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox deleteID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
    }
}