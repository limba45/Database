﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Nurse : Form
    {
        public Nurse()
        {
            InitializeComponent();
        }

        private void Nurse_Load(object sender, EventArgs e)
        {
            DGV.DataSource = GetNurseList();
        }

        private DataTable GetNurseList()
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM Nurse", conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
            return dtDepts;
        }
        private void InsertNurseList(String name, String role, int id)
        {
            try
            {
                DataTable dtDepts = new DataTable();
                String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    String Query = "INSERT INTO Nurse(Nurse.Name, Nurse.Role, Doctor) VALUES('" + name + "', ' " + role + "', " + id + ");";
                    using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                    {
                        conn.Open();
                        MySqlDataReader reader = cmd.ExecuteReader();
                        dtDepts.Load(reader);
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Foreign-key constraint violated");            
            }
            
        }
        private void UpdateNurseList(int id, String name, String role)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "UPDATE Nurse SET Nurse.Name='" + name + "', Nurse.Role=' " + role + "' WHERE Nurse_ID= " + id + ";";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }
        private void DeleteNurseList(int id)
        {
            try
            {
                DataTable dtDepts = new DataTable();
                String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    String Query = "DELETE FROM Nurse WHERE Nurse_ID = " + id + ";";
                    using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                    {
                        conn.Open();
                        MySqlDataReader reader = cmd.ExecuteReader();
                        dtDepts.Load(reader);
                    }
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Cannot delete because of foreign-key constraint", "Error!");
            }

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertNurseList(insertName.Text, insertRole.Text, Int32.Parse(insertDoc.Text));
            DGV.DataSource = GetNurseList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateNurseList(Int32.Parse(updateID.Text), updateName.Text, updateRole.Text);
            DGV.DataSource = GetNurseList();

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteNurseList(Int32.Parse(deleteID.Text));
            DGV.DataSource = GetNurseList();

        }
    }   
}