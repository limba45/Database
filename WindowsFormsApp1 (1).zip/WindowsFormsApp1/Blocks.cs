﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Blocks : Form
    {
        public Blocks()
        {
            InitializeComponent();
        }

        private void Blocks_Load(object sender, EventArgs e)
        {
            DGV.DataSource = GetBlocksList();

        }
        private DataTable GetBlocksList()
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM blocks", conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
            return dtDepts;
        }

        private void InsertBlockList(String name)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "INSERT INTO BLOCKS(BlockName) VALUES('" + name + "')";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }
        private void UpdateBlockList(int id, String name)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "UPDATE Blocks SET BlockName='" + name + "' WHERE Block_ID= " + id + ";";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }
        private void DeleteBlockList(int id)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "DELETE FROM blocks WHERE Block_Id = " + id + ";";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }



        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertBlockList(insertName.Text);
            DGV.DataSource = GetBlocksList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateBlockList(Int32.Parse(updateID.Text), updateName.Text);
            DGV.DataSource = GetBlocksList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteBlockList(Int32.Parse(deleteID.Text));
            DGV.DataSource = GetBlocksList();

        }
    }
}
