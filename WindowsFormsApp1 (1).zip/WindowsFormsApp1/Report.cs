﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            DGV.DataSource = GetReportList();
        }
        private DataTable GetReportList()
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM Report", conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
            return dtDepts;
        }
        private void InsertReportList(int patientID, String name, String date, int amount, String category)
        {
            
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                DateTime rDate = DateTime.Parse(date);
                String Query = @"INSERT INTO REPORT (Patient_ID, ReportName, ReportDate, Amount, Categeory) VALUES (" + patientID + ",'" + name + "', ' + @datee + '," + amount + ",'" + category +"');";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    cmd.Parameters.Add("@datee", MySqlDbType.Datetime).Value = rDate;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void UpdateReportList(int id, String name, String phoneNo)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "UPDATE DEPT SET DeptName='" + name + "', PhoneNumber=' " + phoneNo + "' WHERE Dept_ID= " + id + ";";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }
        private void DeleteReportList(int id)
        {
            try
            {
                DataTable dtDepts = new DataTable();
                String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    String Query = "DELETE FROM Dept WHERE Dept_ID = " + id + ";";
                    using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                    {
                        conn.Open();
                        MySqlDataReader reader = cmd.ExecuteReader();
                        dtDepts.Load(reader);
                    }
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Cannot delete because of foreign-key constraint", "Error!");
            }

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertReportList(Int32.Parse(insertPatient.Text), insertName.Text, insertDate.Text, Int32.Parse(insertAmount.Text), insertCategory.Text);
            DGV.DataSource = GetReportList();
        }
    }
}
