﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Patient : Form
    {
        public Patient()
        {
            InitializeComponent();
        }

        private void Patient_Load(object sender, EventArgs e)
        {
            DGV.DataSource = GetPatientList();
        }
        private DataTable GetPatientList()
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM Patient", conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
            return dtDepts;
        }
    }
}
