﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }




        private void Form1_Load(object sender, EventArgs e)
        {
            DGV.DataSource = GetDepartmentList();
        }
        private DataTable GetDepartmentList()
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM dept", conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader); 
                }
            }
            return dtDepts;
        }
        private void InsertDepartmentList(String name, String phoneNo)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "INSERT INTO DEPT(DeptName, PhoneNumber) VALUES('" + name + "','" + phoneNo + "');";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }

        private void UpdateDepartmentList(int id, String name, String phoneNo)
        {
            DataTable dtDepts = new DataTable();
            String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                String Query = "UPDATE DEPT SET DeptName='" + name + "', PhoneNumber=' " + phoneNo + "' WHERE Dept_ID= " + id + ";";
                using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                {
                    conn.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtDepts.Load(reader);
                }
            }
        }
        private void DeleteDepartmentList(int id)
        {
            try
            {
                DataTable dtDepts = new DataTable();
                String connStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    String Query = "DELETE FROM Dept WHERE Dept_ID = " + id + ";";
                    using (MySqlCommand cmd = new MySqlCommand(Query, conn))
                    {
                        conn.Open();
                        MySqlDataReader reader = cmd.ExecuteReader();
                        dtDepts.Load(reader);
                    }
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Cannot delete because of foreign-key constraint", "Error!");
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertDepartmentList(insertName.Text, insertPhoneNo.Text);
            DGV.DataSource = GetDepartmentList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateDepartmentList(Int32.Parse(updateID.Text), updateName.Text, updatePhoneNo.Text);
            DGV.DataSource = GetDepartmentList();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            DeleteDepartmentList(Int32.Parse(deleteID.Text));
            DGV.DataSource = GetDepartmentList();
        }
    }
}
